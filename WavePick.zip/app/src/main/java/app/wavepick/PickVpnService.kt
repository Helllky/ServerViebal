package app.wavepick

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream

/**
 * Локальный VPN без пересылки трафика: в туннель направлены ТОЛЬКО адреса из списка
 * блокировки и только для приложения игры. Пакеты туда просто отбрасываются,
 * весь остальной трафик идёт мимо VPN как обычно.
 */
class PickVpnService : VpnService() {
    companion object {
        @Volatile var running = false
        @Volatile var lastError: String? = null
        const val STOP = "app.wavepick.STOP"
        val GAME_PACKAGES = listOf("com.mobile.legends", "com.mobilelegends.mi", "com.mobilelegends.hwag")
    }

    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        lastError = null
        val b = Builder().setSession("WavePick").addAddress("10.99.0.2", 32).setBlocking(true)
        var routes = 0
        Store.load(this).filter { it.block }.forEach {
            val ip = it.addr.substringBefore('/')
            val mask = it.addr.substringAfter('/', "32").toIntOrNull() ?: 32
            try { b.addRoute(ip, mask); routes++ } catch (_: Exception) {}
        }
        var apps = 0
        GAME_PACKAGES.forEach { try { b.addAllowedApplication(it); apps++ } catch (_: Exception) {} }
        if (routes == 0) { lastError = "Не выбран ни один сервер для блокировки"; stopSelf(); return START_NOT_STICKY }
        if (apps == 0) { lastError = "Mobile Legends не найден на устройстве"; stopSelf(); return START_NOT_STICKY }
        val fd = b.establish()
        if (fd == null) { lastError = "Не удалось создать VPN"; stopSelf(); return START_NOT_STICKY }
        tun = fd
        running = true
        Thread {
            val input = FileInputStream(fd.fileDescriptor)
            val buf = ByteArray(32767)
            try { while (running) { if (input.read(buf) < 0) break } } catch (_: Exception) {}
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        super.onDestroy()
    }

    override fun onRevoke() { stopSelf() }
}
