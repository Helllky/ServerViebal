package app.wavepick

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

class MainActivity : Activity() {
    private val bg = 0xFF0B1410.toInt()
    private val card = 0xFF16231D.toInt()
    private val fg = 0xFFE3EDE7.toInt()
    private val dim = 0xFF8DA399.toInt()
    private val acc = 0xFF8FC9A6.toInt()

    private lateinit var circle: TextView
    private lateinit var status: TextView
    private lateinit var ipText: TextView
    private lateinit var list: LinearLayout
    private val pings = HashMap<String, String>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(color: Int, r: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        if (oval) setShape(GradientDrawable.OVAL) else setCornerRadius(dp(r).toFloat())
    }
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun btn(t: String, onClick: () -> Unit) = tv(t, 14f, acc, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = box(card, 24)
        setOnClickListener { onClick() }
    }
    private fun key(s: Srv) = "${s.addr}:${s.port}"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(40))
        }
        col.addView(tv("Сервер MLBB", 30f, acc, true))

        val ring = FrameLayout(this).apply { background = box(card, 0, true) }
        circle = tv("Выкл", 22f, bg, true).apply {
            gravity = Gravity.CENTER
            background = box(acc, 0, true)
            setOnClickListener { toggle() }
        }
        ring.addView(circle, FrameLayout.LayoutParams(dp(190), dp(190), Gravity.CENTER))
        col.addView(ring, LinearLayout.LayoutParams(dp(240), dp(240)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(24)
        })
        status = tv("", 14f, dim).apply { gravity = Gravity.CENTER }
        col.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp = { LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) } }
        row.addView(btn("Пинг") { pingAll() }, lp())
        row.addView(btn("Мой IP") { myIp() }, lp())
        row.addView(btn("+ Сервер") { addDialog() }, lp())
        col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })

        ipText = tv("", 13f, dim)
        col.addView(ipText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        col.addView(tv("СЕРВЕРЫ", 12f, dim, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
        col.addView(tv("Включённый переключатель = блокировать этот сервер для игры. Долгое нажатие на строку — удалить.",
            12f, dim), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        scroll.addView(col)
        setContentView(scroll)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val on = PickVpnService.running
        circle.text = if (on) "Защита\nвкл" else "Выкл"
        status.text = PickVpnService.lastError
            ?: if (on) "Игра не сможет подключаться к отмеченным серверам"
            else "Отметьте серверы для блокировки и нажмите на круг"
        list.removeAllViews()
        val items = Store.load(this)
        if (items.isEmpty()) list.addView(tv("Пока пусто. Добавьте сервер кнопкой «+ Сервер».", 14f, fg))
        items.forEachIndexed { i, s ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12)); background = box(card, 16)
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Удалить «${s.name}»?")
                        .setPositiveButton("Удалить") { _, _ ->
                            val l = Store.load(this@MainActivity); l.removeAt(i); Store.save(this@MainActivity, l); refresh()
                        }.setNegativeButton("Отмена", null).show()
                    true
                }
            }
            val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            names.addView(tv(s.name, 16f, fg, true))
            names.addView(tv("${s.addr}:${s.port}", 12f, dim))
            r.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(tv(pings[key(s)] ?: "", 14f, acc), LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) })
            r.addView(Switch(this).apply {
                isChecked = s.block
                setOnCheckedChangeListener { _, c ->
                    val l = Store.load(this@MainActivity); l[i].block = c; Store.save(this@MainActivity, l)
                    if (PickVpnService.running) status.text = "Перезапустите защиту, чтобы применить"
                }
            })
            list.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun toggle() {
        if (PickVpnService.running) {
            startService(Intent(this, PickVpnService::class.java).setAction(PickVpnService.STOP))
            circle.postDelayed({ refresh() }, 500)
        } else {
            val i = VpnService.prepare(this)
            if (i != null) startActivityForResult(i, 1) else startVpn()
        }
    }

    private fun startVpn() {
        startService(Intent(this, PickVpnService::class.java))
        circle.postDelayed({ refresh() }, 700)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK) startVpn()
    }

    private fun pingAll() {
        Store.load(this).forEach { s ->
            Thread {
                val t = System.nanoTime()
                val r = try {
                    Socket().use { it.connect(InetSocketAddress(s.addr.substringBefore('/'), s.port), 2000) }
                    "${(System.nanoTime() - t) / 1_000_000} мс"
                } catch (e: java.net.ConnectException) {
                    "${(System.nanoTime() - t) / 1_000_000} мс"
                } catch (e: Exception) { "—" }
                runOnUiThread { pings[key(s)] = r; refresh() }
            }.start()
        }
    }

    private fun myIp() {
        ipText.text = "Запрашиваю…"
        Thread {
            val r = try {
                val c = URL("https://ip.ml.youngjoygame.com/myip").openConnection() as HttpURLConnection
                c.connectTimeout = 4000; c.readTimeout = 4000
                c.inputStream.bufferedReader().readText().trim().take(200)
            } catch (e: Exception) { "ошибка: ${e.message}" }
            runOnUiThread { ipText.text = "IP глазами игры: $r" }
        }.start()
    }

    private fun addDialog() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val n = EditText(this).apply { hint = "Название (например SG-1)" }
        val a = EditText(this).apply { hint = "IPv4 или сеть (1.2.3.0/24)" }
        val p = EditText(this).apply { hint = "Порт для пинга"; setText("443"); inputType = InputType.TYPE_CLASS_NUMBER }
        form.addView(n); form.addView(a); form.addView(p)
        AlertDialog.Builder(this).setTitle("Новый сервер").setView(form)
            .setPositiveButton("Добавить") { _, _ ->
                val addr = a.text.toString().trim()
                if (!Regex("""^\d{1,3}(\.\d{1,3}){3}(/\d{1,2})?$""").matches(addr)) {
                    Toast.makeText(this, "Нужен IPv4-адрес или сеть", Toast.LENGTH_SHORT).show(); return@setPositiveButton
                }
                val l = Store.load(this)
                l += Srv(n.text.toString().ifBlank { addr }, addr, p.text.toString().toIntOrNull() ?: 443, true)
                Store.save(this, l); refresh()
            }.setNegativeButton("Отмена", null).show()
    }
}
