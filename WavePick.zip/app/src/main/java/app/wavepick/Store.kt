package app.wavepick

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Srv(val name: String, val addr: String, val port: Int, var block: Boolean)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("wavepick", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Srv> {
        val out = mutableListOf<Srv>()
        try {
            val a = JSONArray(prefs(c).getString("servers", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out += Srv(o.getString("name"), o.getString("addr"), o.getInt("port"), o.getBoolean("block"))
            }
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, list: List<Srv>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("name", it.name).put("addr", it.addr).put("port", it.port).put("block", it.block)) }
        prefs(c).edit().putString("servers", a.toString()).apply()
    }
}
